# Change Log

All notable changes to the "Midnight Aurora Theme" extension will be documented in this file.

## [0.0.1]

- Initial release
