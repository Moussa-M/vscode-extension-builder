import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
  console.log('Extension "Midnight Aurora Theme" is now active!');

  // Register your commands and providers here
}

export function deactivate() {}