# My Theme

A beautiful dark theme for VS Code.

## Installation

1. Install the extension
2. Go to File > Preferences > Color Theme
3. Select "My Theme"